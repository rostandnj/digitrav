<?php
/**
 * Created by PhpStorm.
 * User: rostandnj
 * Date: 13/3/19
 * Time: 2:02 PM
 */
namespace App\Service;


use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

use App\Entity\System;
use App\Entity\Role;
use App\Entity\City;
use App\Entity\User;
use App\Entity\Location;

class SystemService
{
    private $em;
    private $container;

    public function __construct(EntityManagerInterface $em,ContainerInterface $c)
    {
        $this->em = $em;
        $this->container = $c;
    }

    public function getStatut()
    {
        $sys= $this->em->getRepository(System::class)->findAll();
        $nb = count($sys);
        if($nb==0)
        {
            return ["message"=>"system empty","statut"=>0];
        }
        else{

            if($nb==1)
            {
                if($sys[0]->getStatut()==true) return ["message"=>"system already initialised","statut"=>1];
                else return ["message"=>"system empty","statut"=>0];
            }
            else{
                return ["message"=>"system error because of multiple entry of system. please drop the database","statut"=>1];
            }

        }
    }

    public function initSystem()
    {
        $town = array(
            array('name' => 'Douala'),
            array('name' => 'Yaoundé'),
            array('name' => 'Bafoussam'),
            array('name' => 'Ringo'),
            array('name' => 'Bamenda'),
            array('name' => 'Ngaoundéré'),
            array('name' => 'Tibati'),
            array('name' => 'Kumba'),
            array('name' => 'Buea'),
            array('name' => 'Bafia'),
            array('name' => 'Kribi'),
            array('name' => 'Limbe'),
            array('name' => 'Mbouda'),
            array('name' => 'Maroua'),
            array('name' => 'Garoua'),
            array('name' => 'Nkongsamba'),
            array('name' => 'Djoum'),
            array('name' => 'Sangmelima'),
            array('name' => 'Ebolowa'),
            array('name' => 'Bertoua'),
            array('name' => 'Loum'),
            array('name' => 'Edéa'),
            array('name' => 'Kumbo'),
            array('name' => 'Foumban'),
            array('name' => 'Dschang'),
            array('name' => 'Bandjoun'),
            array('name' => 'Kousséri'),
            array('name' => 'Maroua'),
            array('name' => 'Guider'),
            array('name' => 'Meiganga'),
            array('name' => 'Batouri'),
            array('name' => 'Yagoua'),
            array('name' => 'Mbalmayo'),
            array('name' => 'Bafang'),
            array('name' => 'Tiko'),
            array('name' => 'Bafia'),
            array('name' => 'Wum'),
            array('name' => 'Kribi'),
            array('name' => 'Foumbot'),
            array('name' => 'Bagangté'),
            array('name' => 'Banyo'),
            array('name' => 'Nkambé'),
            array('name' => 'Bali'),
            array('name' => 'Mbanga'),
            array('name' => 'Mokolo'),
            array('name' => 'Melong'),
            array('name' => 'Manjo'),
            array('name' => 'Mora'),
            array('name' => 'Kaélé'),
            array('name' => 'Tibati'),
            array('name' => 'Ndop'),
            array('name' => 'Akonolinga'),
            array('name' => 'Eseka'),
            array('name' => 'Mamfé'),
            array('name' => 'Obala'),
            array('name' => 'Muyuka'),
            array('name' => 'Nanga-Eboko'),
            array('name' => 'Monatélé'),
            array('name' => 'Abong-Mbang'),
            array('name' => 'Fundong'),
            array('name' => 'Nkoteng'),
            array('name' => 'Fontem'),
            array('name' => 'Mbandjock'),
            array('name' => 'Garoua-Boulai'),
            array('name' => 'Touboro'),
            array('name' => 'Ngaoundal'),
            array('name' => 'Yokadouma'),
            array('name' => 'Pitoa'),
            array('name' => 'Tombel'),
            array('name' => 'Kékem'),
            array('name' => 'Magba'),
            array('name' => 'Bélabo'),
            array('name' => 'Tonga'),
            array('name' => 'Tonga'),
            array('name' => 'Maga'),
            array('name' => 'Koutaba'),
            array('name' => 'Blangoua'),
            array('name' => 'Guidiguis'),
            array('name' => 'Bogo'),
            array('name' => 'Batibo'),
            array('name' => 'Yabassi'),
            array('name' => 'Figuil'),
            array('name' => 'Makénéné'),
            array('name' => 'Gazawa'),
            array('name' => 'Tcholliré'),
            array('name' => 'Oveng'),
            array('name' => 'Mintom'),
            array('name' => 'Mfou'),
            array('name' => 'Ngoumou'),
            array('name' => 'Baham'),
            array('name' => 'Yoko')
        );

        $role = array("ROLE_CLIENT","ROLE_OPERATOR","ROLE_ADMIN","ROLE_SADMIN","ROLE_TECHNICIAN_COMPANY","ROLE_TECHNICIAN_PERSON",
            "ROLE_MANAGER_COMPANY","ROLE_SYSTEM"
        );

        foreach ($town as $el)
        {
            $q = new City();
            $q->setName($el["name"]);

            $this->em->persist($q);
        }

        foreach ($role as $el)
        {
            $role = new Role();
            $role->setCode($el);

            $this->em->persist($role);
        }

        $this->em->flush();

        $role = $this->em->getRepository(Role::class)->findOneBy(array("code"=>"ROLE_SADMIN"));
        $role2 = $this->em->getRepository(Role::class)->findOneBy(array("code"=>"ROLE_SYSTEM"));

        if(is_null($role) || is_null($role2) ) return ["message"=>"no role for sdamin or system found","statut"=>0];
        else
        {
            $user = new User();
            $user->setName("sadmin");
            $user->setSurname("digitrav");
            $user->setEmail("sadmin@digitrav.com");
            $user->setGender(true);
            $user->setIsValid(true);
            $user->setPhone("00237699884455");
            $user->setIsClose(false);
            $user->setPassword($this->container->get("security.password_encoder")->encodePassword($user,'123456' ));


            $location = new Location();
            $location->setCity("Yaoundé");
            $location->setQuater("Bastos");

            $user->setLocation($location);
            $user->setRole($role);


            $user2 = new User();
            $user2->setName("admin");
            $user2->setSurname("digitrav");
            $user2->setEmail("admin@digitrav.com");
            $user2->setGender(true);
            $user2->setIsValid(true);
            $user2->setPhone("00237699884433");
            $user2->setIsClose(false);
            $user2->setPassword($this->container->get("security.password_encoder")->encodePassword($user2,'123456aA' ));




            $location2 = new Location();
            $location2->setCity("Yaoundé");
            $location2->setQuater("Bastos");

            $user2->setLocation($location2);
            $user2->setRole($role2);

            $this->em->persist($user);
            $this->em->persist($user2);

            $s = new System();
            $s->setStatut(true);
            $this->em->persist($s);

            $this->em->flush();


            return ["message"=>"system initialised","statut"=>1];

        }


    }
}